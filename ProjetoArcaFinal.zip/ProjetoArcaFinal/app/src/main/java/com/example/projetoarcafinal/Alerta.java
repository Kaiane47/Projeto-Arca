package com.example.projetoarcafinal;

public class Alerta {
    private int id;
    private String titulo;
    private String descricao;
    private String dataHora;
    private String nivelRisco; // "Alto", "Médio", "Baixo"

    public Alerta() {
    }

    public Alerta(int id, String titulo, String descricao, String dataHora, String nivelRisco) {
        this.id = id;
        this.titulo = titulo;
        this.descricao = descricao;
        this.dataHora = dataHora;
        this.nivelRisco = nivelRisco;
    }

    public Alerta(String titulo, String descricao, String dataHora, String nivelRisco) {
        this.titulo = titulo;
        this.descricao = descricao;
        this.dataHora = dataHora;
        this.nivelRisco = nivelRisco;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public String getDataHora() {
        return dataHora;
    }

    public void setDataHora(String dataHora) {
        this.dataHora = dataHora;
    }

    public String getNivelRisco() {
        return nivelRisco;
    }

    public void setNivelRisco(String nivelRisco) {
        this.nivelRisco = nivelRisco;
    }
}
