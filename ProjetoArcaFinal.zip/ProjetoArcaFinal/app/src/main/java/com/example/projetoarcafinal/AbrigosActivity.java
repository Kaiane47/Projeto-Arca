package com.example.projetoarcafinal;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.util.List;

public class AbrigosActivity extends AppCompatActivity {

    private EditText edtNomeAbrigo;
    private EditText edtLocalizacaoAbrigo;
    private EditText edtVagasAbrigo;
    private EditText edtOcupacaoAbrigo;
    private Button btnSalvarAbrigo;
    private Button btnCancelarAbrigo;
    private TextView txtTituloFormAbrigo;
    private LinearLayout containerAbrigos;

    private View btnNavPainel;
    private View btnNavAlertas;

    private DatabaseHelper databaseHelper;
    private int selectedAbrigoId = -1; // -1 indica novo cadastro

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_abrigos);

        databaseHelper = new DatabaseHelper(this);

        edtNomeAbrigo = findViewById(R.id.edtNomeAbrigo);
        edtLocalizacaoAbrigo = findViewById(R.id.edtLocalizacaoAbrigo);
        edtVagasAbrigo = findViewById(R.id.edtVagasAbrigo);
        edtOcupacaoAbrigo = findViewById(R.id.edtOcupacaoAbrigo);
        btnSalvarAbrigo = findViewById(R.id.btnSalvarAbrigo);
        btnCancelarAbrigo = findViewById(R.id.btnCancelarAbrigo);
        txtTituloFormAbrigo = findViewById(R.id.txtTituloFormAbrigo);
        containerAbrigos = findViewById(R.id.containerAbrigos);

        btnNavPainel = findViewById(R.id.btnNavPainel);
        btnNavAlertas = findViewById(R.id.btnNavAlertas);

        btnSalvarAbrigo.setOnClickListener(v -> salvarAbrigo());
        btnCancelarAbrigo.setOnClickListener(v -> resetForm());

        btnNavPainel.setOnClickListener(v -> {
            Intent intent = new Intent(AbrigosActivity.this, MainActivity.class);
            startActivity(intent);
            finish();
        });

        btnNavAlertas.setOnClickListener(v -> {
            Intent intent = new Intent(AbrigosActivity.this, AlertasActivity.class);
            startActivity(intent);
            finish();
        });

        carregarAbrigos();
    }

    private void salvarAbrigo() {
        String nome = edtNomeAbrigo.getText().toString().trim();
        String loc = edtLocalizacaoAbrigo.getText().toString().trim();
        String vagasStr = edtVagasAbrigo.getText().toString().trim();
        String ocupacaoStr = edtOcupacaoAbrigo.getText().toString().trim();

        if (TextUtils.isEmpty(nome)) {
            edtNomeAbrigo.setError("Informe o nome do abrigo");
            return;
        }
        if (TextUtils.isEmpty(loc)) {
            edtLocalizacaoAbrigo.setError("Informe a localização");
            return;
        }

        int vagas = TextUtils.isEmpty(vagasStr) ? 0 : Integer.parseInt(vagasStr);
        int ocupacao = TextUtils.isEmpty(ocupacaoStr) ? 0 : Integer.parseInt(ocupacaoStr);

        if (selectedAbrigoId == -1) {
            // Inserir
            Abrigo novoAbrigo = new Abrigo(nome, loc, vagas, ocupacao);
            long res = databaseHelper.insertAbrigo(novoAbrigo);
            if (res > 0) {
                Toast.makeText(this, "Abrigo cadastrado com sucesso!", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Erro ao cadastrar abrigo.", Toast.LENGTH_SHORT).show();
            }
        } else {
            // Atualizar
            Abrigo abrigoEdit = new Abrigo(selectedAbrigoId, nome, loc, vagas, ocupacao);
            int res = databaseHelper.updateAbrigo(abrigoEdit);
            if (res > 0) {
                Toast.makeText(this, "Abrigo atualizado com sucesso!", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Erro ao atualizar abrigo.", Toast.LENGTH_SHORT).show();
            }
        }

        resetForm();
        carregarAbrigos();
    }

    private void resetForm() {
        selectedAbrigoId = -1;
        edtNomeAbrigo.setText("");
        edtLocalizacaoAbrigo.setText("");
        edtVagasAbrigo.setText("");
        edtOcupacaoAbrigo.setText("");
        txtTituloFormAbrigo.setText("Cadastrar Novo Abrigo");
        btnSalvarAbrigo.setText("Salvar Abrigo");
        btnCancelarAbrigo.setVisibility(View.GONE);
    }
    private void carregarAbrigos() {
        containerAbrigos.removeAllViews();
        List<Abrigo> list = databaseHelper.getAllAbrigos();

        for (Abrigo a : list) {
            View itemView = criarViewAbrigo(a);
            containerAbrigos.addView(itemView);
        }
    }

    private View criarViewAbrigo(Abrigo abrigo) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackgroundColor(Color.WHITE);
        card.setPadding(32, 32, 32, 32);

        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        params.setMargins(0, 0, 0, 24);
        card.setLayoutParams(params);

        // Linha principal de info
        LinearLayout rowInfo = new LinearLayout(this);
        rowInfo.setOrientation(LinearLayout.HORIZONTAL);
        rowInfo.setGravity(android.view.Gravity.CENTER_VERTICAL);

        ImageView imgIcon = new ImageView(this);
        LinearLayout.LayoutParams imgParams = new LinearLayout.LayoutParams(110, 110);
        imgIcon.setLayoutParams(imgParams);
        imgIcon.setImageResource(R.drawable.ic_abrigo);

        LinearLayout colText = new LinearLayout(this);
        colText.setOrientation(LinearLayout.VERTICAL);
        colText.setPadding(20, 0, 0, 0);
        LinearLayout.LayoutParams colParams = new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.0f
        );
        colText.setLayoutParams(colParams);

        TextView txtNome = new TextView(this);
        txtNome.setText(abrigo.getNome());
        txtNome.setTextSize(17);
        txtNome.setTypeface(null, android.graphics.Typeface.BOLD);
        txtNome.setTextColor(Color.parseColor("#102B55"));

        TextView txtLoc = new TextView(this);
        txtLoc.setText("📍 " + abrigo.getLocalizacao());
        txtLoc.setTextSize(14);
        txtLoc.setTextColor(Color.parseColor("#102B55"));
        txtLoc.setPadding(0, 4, 0, 4);

        TextView txtVagas = new TextView(this);
        txtVagas.setText("👥 " + abrigo.getVagasLivres() + " vagas livres");
        txtVagas.setTextSize(14);
        txtVagas.setTextColor(Color.parseColor("#102B55"));

        colText.addView(txtNome);
        colText.addView(txtLoc);
        colText.addView(txtVagas);

        // Bloco ocupação
        LinearLayout colOcup = new LinearLayout(this);
        colOcup.setOrientation(LinearLayout.VERTICAL);
        colOcup.setGravity(android.view.Gravity.CENTER);
        LinearLayout.LayoutParams ocupParams = new LinearLayout.LayoutParams(150, LinearLayout.LayoutParams.WRAP_CONTENT);
        colOcup.setLayoutParams(ocupParams);

        TextView txtPorcentagem = new TextView(this);
        txtPorcentagem.setText(abrigo.getOcupacao() + "%");
        txtPorcentagem.setTextSize(20);
        txtPorcentagem.setTypeface(null, android.graphics.Typeface.BOLD);
        txtPorcentagem.setTextColor(abrigo.getOcupacao() > 75 ? Color.parseColor("#F28A16") : Color.parseColor("#123B70"));

        TextView txtOcupLabel = new TextView(this);
        txtOcupLabel.setText("Ocupação");
        txtOcupLabel.setTextSize(12);
        txtOcupLabel.setTextColor(Color.parseColor("#102B55"));

        colOcup.addView(txtPorcentagem);
        colOcup.addView(txtOcupLabel);

        rowInfo.addView(imgIcon);
        rowInfo.addView(colText);
        rowInfo.addView(colOcup);

        // Linha de botões de Ação (Editar e Excluir)
        LinearLayout rowActions = new LinearLayout(this);
        rowActions.setOrientation(LinearLayout.HORIZONTAL);
        rowActions.setGravity(android.view.Gravity.END);
        rowActions.setPadding(0, 16, 0, 0);

        Button btnEditar = new Button(this);
        btnEditar.setText("Editar");
        btnEditar.setTextSize(12);
        btnEditar.setTextColor(Color.parseColor("#123B70"));
        btnEditar.setBackgroundColor(Color.parseColor("#E0E6ED"));
        LinearLayout.LayoutParams btnEditParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, 90
        );
        btnEditParams.setMargins(0, 0, 16, 0);
        btnEditar.setLayoutParams(btnEditParams);

        Button btnExcluir = new Button(this);
        btnExcluir.setText("Excluir");
        btnExcluir.setTextSize(12);
        btnExcluir.setTextColor(Color.WHITE);
        btnExcluir.setBackgroundColor(Color.parseColor("#D32F2F"));
        LinearLayout.LayoutParams btnDelParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, 90
        );
        btnExcluir.setLayoutParams(btnDelParams);

        btnEditar.setOnClickListener(v -> {
            selectedAbrigoId = abrigo.getId();
            edtNomeAbrigo.setText(abrigo.getNome());
            edtLocalizacaoAbrigo.setText(abrigo.getLocalizacao());
            edtVagasAbrigo.setText(String.valueOf(abrigo.getVagasLivres()));
            edtOcupacaoAbrigo.setText(String.valueOf(abrigo.getOcupacao()));
            txtTituloFormAbrigo.setText("Editar Abrigo ID: " + abrigo.getId());
            btnSalvarAbrigo.setText("Atualizar Abrigo");
            btnCancelarAbrigo.setVisibility(View.VISIBLE);
        });

        btnExcluir.setOnClickListener(v -> {
            new AlertDialog.Builder(this)
                    .setTitle("Excluir Abrigo")
                    .setMessage("Deseja realmente excluir " + abrigo.getNome() + "?")
                    .setPositiveButton("Sim", (dialog, which) -> {
                        databaseHelper.deleteAbrigo(abrigo.getId());
                        Toast.makeText(this, "Abrigo excluído!", Toast.LENGTH_SHORT).show();
                        if (selectedAbrigoId == abrigo.getId()) {
                            resetForm();
                        }
                        carregarAbrigos();
                    })
                    .setNegativeButton("Não", null)
                    .show();
        });

        rowActions.addView(btnEditar);
        rowActions.addView(btnExcluir);

        card.addView(rowInfo);
        card.addView(rowActions);

        return card;
    }
}
