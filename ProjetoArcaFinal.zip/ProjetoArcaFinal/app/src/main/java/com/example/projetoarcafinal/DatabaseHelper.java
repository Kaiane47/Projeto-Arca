package com.example.projetoarcafinal;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "arca.db";
    private static final int DATABASE_VERSION = 1;

    // Tabela Abrigos
    public static final String TABLE_ABRIGOS = "abrigos";
    public static final String COLUMN_ABRIGO_ID = "id";
    public static final String COLUMN_ABRIGO_NOME = "nome";
    public static final String COLUMN_ABRIGO_LOCALIZACAO = "localizacao";
    public static final String COLUMN_ABRIGO_VAGAS = "vagas_livres";
    public static final String COLUMN_ABRIGO_OCUPACAO = "ocupacao";
    // Tabela Alertas
    public static final String TABLE_ALERTAS = "alertas";
    public static final String COLUMN_ALERTA_ID = "id";
    public static final String COLUMN_ALERTA_TITULO = "titulo";
    public static final String COLUMN_ALERTA_DESCRICAO = "descricao";
    public static final String COLUMN_ALERTA_DATA_HORA = "data_hora";
    public static final String COLUMN_ALERTA_RISCO = "nivel_risco";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createAbrigosTable = "CREATE TABLE " + TABLE_ABRIGOS + " (" +
                COLUMN_ABRIGO_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_ABRIGO_NOME + " TEXT, " +
                COLUMN_ABRIGO_LOCALIZACAO + " TEXT, " +
                COLUMN_ABRIGO_VAGAS + " INTEGER, " +
                COLUMN_ABRIGO_OCUPACAO + " INTEGER)";

        String createAlertasTable = "CREATE TABLE " + TABLE_ALERTAS + " (" +
                COLUMN_ALERTA_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_ALERTA_TITULO + " TEXT, " +
                COLUMN_ALERTA_DESCRICAO + " TEXT, " +
                COLUMN_ALERTA_DATA_HORA + " TEXT, " +
                COLUMN_ALERTA_RISCO + " TEXT)";

        db.execSQL(createAbrigosTable);
        db.execSQL(createAlertasTable);


        insertInitialData(db);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_ABRIGOS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_ALERTAS);
        onCreate(db);
    }

    private void insertInitialData(SQLiteDatabase db) {

        ContentValues cv1 = new ContentValues();
        cv1.put(COLUMN_ABRIGO_NOME, "Abrigo Municipal");
        cv1.put(COLUMN_ABRIGO_LOCALIZACAO, "Centro");
        cv1.put(COLUMN_ABRIGO_VAGAS, 45);
        cv1.put(COLUMN_ABRIGO_OCUPACAO, 62);
        db.insert(TABLE_ABRIGOS, null, cv1);

        ContentValues cv2 = new ContentValues();
        cv2.put(COLUMN_ABRIGO_NOME, "Ginásio Poliesportivo");
        cv2.put(COLUMN_ABRIGO_LOCALIZACAO, "Vila Nova");
        cv2.put(COLUMN_ABRIGO_VAGAS, 120);
        cv2.put(COLUMN_ABRIGO_OCUPACAO, 85);
        db.insert(TABLE_ABRIGOS, null, cv2);

        ContentValues cv3 = new ContentValues();
        cv3.put(COLUMN_ABRIGO_NOME, "Escola Estadual");
        cv3.put(COLUMN_ABRIGO_LOCALIZACAO, "Morro Alto");
        cv3.put(COLUMN_ABRIGO_VAGAS, 30);
        cv3.put(COLUMN_ABRIGO_OCUPACAO, 40);
        db.insert(TABLE_ABRIGOS, null, cv3);

        ContentValues ca1 = new ContentValues();
        ca1.put(COLUMN_ALERTA_TITULO, "Risco Alto");
        ca1.put(COLUMN_ALERTA_DESCRICAO, "Chuvas intensas na região.");
        ca1.put(COLUMN_ALERTA_DATA_HORA, "Hoje • 14:30");
        ca1.put(COLUMN_ALERTA_RISCO, "Alto");
        db.insert(TABLE_ALERTAS, null, ca1);

        ContentValues ca2 = new ContentValues();
        ca2.put(COLUMN_ALERTA_TITULO, "Risco Médio");
        ca2.put(COLUMN_ALERTA_DESCRICAO, "Possível alagamento.");
        ca2.put(COLUMN_ALERTA_DATA_HORA, "Hoje • 12:15");
        ca2.put(COLUMN_ALERTA_RISCO, "Médio");
        db.insert(TABLE_ALERTAS, null, ca2);

        ContentValues ca3 = new ContentValues();
        ca3.put(COLUMN_ALERTA_TITULO, "Risco Baixo");
        ca3.put(COLUMN_ALERTA_DESCRICAO, "Aumento no nível do rio.");
        ca3.put(COLUMN_ALERTA_DATA_HORA, "Hoje • 10:20");
        ca3.put(COLUMN_ALERTA_RISCO, "Baixo");
        db.insert(TABLE_ALERTAS, null, ca3);
    }

    public long insertAbrigo(Abrigo abrigo) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_ABRIGO_NOME, abrigo.getNome());
        values.put(COLUMN_ABRIGO_LOCALIZACAO, abrigo.getLocalizacao());
        values.put(COLUMN_ABRIGO_VAGAS, abrigo.getVagasLivres());
        values.put(COLUMN_ABRIGO_OCUPACAO, abrigo.getOcupacao());

        return db.insert(TABLE_ABRIGOS, null, values);
    }

    public List<Abrigo> getAllAbrigos() {
        List<Abrigo> list = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_ABRIGOS + " ORDER BY " + COLUMN_ABRIGO_ID + " DESC", null);

        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ABRIGO_ID));
                String nome = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_ABRIGO_NOME));
                String loc = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_ABRIGO_LOCALIZACAO));
                int vagas = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ABRIGO_VAGAS));
                int ocupacao = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ABRIGO_OCUPACAO));

                list.add(new Abrigo(id, nome, loc, vagas, ocupacao));
            } while (cursor.moveToNext());
        }
        cursor.close();
        return list;
    }

    public int updateAbrigo(Abrigo abrigo) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_ABRIGO_NOME, abrigo.getNome());
        values.put(COLUMN_ABRIGO_LOCALIZACAO, abrigo.getLocalizacao());
        values.put(COLUMN_ABRIGO_VAGAS, abrigo.getVagasLivres());
        values.put(COLUMN_ABRIGO_OCUPACAO, abrigo.getOcupacao());

        return db.update(TABLE_ABRIGOS, values, COLUMN_ABRIGO_ID + " = ?",
                new String[]{String.valueOf(abrigo.getId())});
    }

    public int deleteAbrigo(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(TABLE_ABRIGOS, COLUMN_ABRIGO_ID + " = ?",
                new String[]{String.valueOf(id)});
    }

    public int getAbrigosCount() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT COUNT(*) FROM " + TABLE_ABRIGOS, null);
        int count = 0;
        if (cursor.moveToFirst()) {
            count = cursor.getInt(0);
        }
        cursor.close();
        return count;
    }

    public long insertAlerta(Alerta alerta) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_ALERTA_TITULO, alerta.getTitulo());
        values.put(COLUMN_ALERTA_DESCRICAO, alerta.getDescricao());
        values.put(COLUMN_ALERTA_DATA_HORA, alerta.getDataHora());
        values.put(COLUMN_ALERTA_RISCO, alerta.getNivelRisco());

        return db.insert(TABLE_ALERTAS, null, values);
    }

    public List<Alerta> getAllAlertas() {
        List<Alerta> list = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_ALERTAS + " ORDER BY " + COLUMN_ALERTA_ID + " DESC", null);

        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ALERTA_ID));
                String titulo = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_ALERTA_TITULO));
                String desc = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_ALERTA_DESCRICAO));
                String dataHora = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_ALERTA_DATA_HORA));
                String risco = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_ALERTA_RISCO));

                list.add(new Alerta(id, titulo, desc, dataHora, risco));
            } while (cursor.moveToNext());
        }
        cursor.close();
        return list;
    }

    public int updateAlerta(Alerta alerta) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_ALERTA_TITULO, alerta.getTitulo());
        values.put(COLUMN_ALERTA_DESCRICAO, alerta.getDescricao());
        values.put(COLUMN_ALERTA_DATA_HORA, alerta.getDataHora());
        values.put(COLUMN_ALERTA_RISCO, alerta.getNivelRisco());

        return db.update(TABLE_ALERTAS, values, COLUMN_ALERTA_ID + " = ?",
                new String[]{String.valueOf(alerta.getId())});
    }

    public int deleteAlerta(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(TABLE_ALERTAS, COLUMN_ALERTA_ID + " = ?",
                new String[]{String.valueOf(id)});
    }

    public int getAlertasCount() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT COUNT(*) FROM " + TABLE_ALERTAS, null);
        int count = 0;
        if (cursor.moveToFirst()) {
            count = cursor.getInt(0);
        }
        cursor.close();
        return count;
    }
}
