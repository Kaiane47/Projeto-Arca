package com.example.projetoarcafinal;

public class Abrigo {
    private int id;
    private String nome;
    private String localizacao;
    private int vagasLivres;
    private int ocupacao;

    public Abrigo() {
    }

    public Abrigo(int id, String nome, String localizacao, int vagasLivres, int ocupacao) {
        this.id = id;
        this.nome = nome;
        this.localizacao = localizacao;
        this.vagasLivres = vagasLivres;
        this.ocupacao = ocupacao;
    }

    public Abrigo(String nome, String localizacao, int vagasLivres, int ocupacao) {
        this.nome = nome;
        this.localizacao = localizacao;
        this.vagasLivres = vagasLivres;
        this.ocupacao = ocupacao;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getLocalizacao() {
        return localizacao;
    }

    public void setLocalizacao(String localizacao) {
        this.localizacao = localizacao;
    }

    public int getVagasLivres() {
        return vagasLivres;
    }

    public void setVagasLivres(int vagasLivres) {
        this.vagasLivres = vagasLivres;
    }

    public int getOcupacao() {
        return ocupacao;
    }

    public void setOcupacao(int ocupacao) {
        this.ocupacao = ocupacao;
    }
}
