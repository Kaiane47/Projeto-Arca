package com.example.projetoarcafinal;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private TextView txtCountAbrigos;
    private TextView txtCountAlertas;
    private View btnNavAbrigos;
    private View btnNavAlertas;
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        databaseHelper = new DatabaseHelper(this);

        txtCountAbrigos = findViewById(R.id.txtCountAbrigos);
        txtCountAlertas = findViewById(R.id.txtCountAlertas);
        btnNavAbrigos = findViewById(R.id.btnNavAbrigos);
        btnNavAlertas = findViewById(R.id.btnNavAlertas);

        btnNavAbrigos.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, AbrigosActivity.class);
            startActivity(intent);
        });

        btnNavAlertas.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, AlertasActivity.class);
            startActivity(intent);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateCounts();
    }

    private void updateCounts() {
        int countAbrigos = databaseHelper.getAbrigosCount();
        int countAlertas = databaseHelper.getAlertasCount();

        if (txtCountAbrigos != null) {
            txtCountAbrigos.setText(String.valueOf(countAbrigos));
        }
        if (txtCountAlertas != null) {
            txtCountAlertas.setText(String.valueOf(countAlertas));
        }
    }
}
