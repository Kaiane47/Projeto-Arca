package com.example.projetoarcafinal;

import java.util.ArrayList;
import java.util.List;

public class CrudRepositorio {

    private static final List<Abrigo> abrigos = new ArrayList<>();
    private static final List<Alerta> alertas = new ArrayList<>();
    public static void criarAbrigo(Abrigo abrigo) {
        abrigos.add(abrigo);
    }
    public static List<Abrigo> listarAbrigos() {
        return abrigos;
    }
    public static void atualizarAbrigo(int indice, Abrigo abrigo) {
        if (indice >= 0 && indice < abrigos.size()) {
            abrigos.set(indice, abrigo);
        }
    }
    public static void removerAbrigo(int indice) {
        if (indice >= 0 && indice < abrigos.size()) {
            abrigos.remove(indice);
        }
    }
    public static void criarAlerta(Alerta alerta) {
        alertas.add(alerta);
    }
    public static List<Alerta> listarAlertas() {
        return alertas;
    }
    public static void atualizarAlerta(int indice, Alerta alerta) {
        if (indice >= 0 && indice < alertas.size()) {
            alertas.set(indice, alerta);
        }
    }
    public static void removerAlerta(int indice) {
        if (indice >= 0 && indice < alertas.size()) {
            alertas.remove(indice);
        }
    }
}