package com.example.projetoarcafinal;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class AlertasActivity extends AppCompatActivity {

    private EditText edtTituloAlerta;
    private EditText edtDescricaoAlerta;
    private EditText edtDataHoraAlerta;
    private Spinner spnNivelRiscoAlerta;
    private Button btnSalvarAlerta;
    private Button btnCancelarAlerta;
    private TextView txtTituloFormAlerta;
    private LinearLayout containerAlertas;

    private View btnNavPainel;
    private View btnNavAbrigos;

    private DatabaseHelper databaseHelper;
    private int selectedAlertaId = -1; // -1 para novo alerta

    private static final String[] OPCOES_RISCO = {"Alto", "Médio", "Baixo"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alertas);

        databaseHelper = new DatabaseHelper(this);

        edtTituloAlerta = findViewById(R.id.edtTituloAlerta);
        edtDescricaoAlerta = findViewById(R.id.edtDescricaoAlerta);
        edtDataHoraAlerta = findViewById(R.id.edtDataHoraAlerta);
        spnNivelRiscoAlerta = findViewById(R.id.spnNivelRiscoAlerta);
        btnSalvarAlerta = findViewById(R.id.btnSalvarAlerta);
        btnCancelarAlerta = findViewById(R.id.btnCancelarAlerta);
        txtTituloFormAlerta = findViewById(R.id.txtTituloFormAlerta);
        containerAlertas = findViewById(R.id.containerAlertas);

        btnNavPainel = findViewById(R.id.btnNavPainel);
        btnNavAbrigos = findViewById(R.id.btnNavAbrigos);

        ArrayAdapter<String> adapterRisco = new ArrayAdapter<>(
                this, android.R.layout.simple_spinner_item, OPCOES_RISCO
        );
        adapterRisco.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spnNivelRiscoAlerta.setAdapter(adapterRisco);

        btnSalvarAlerta.setOnClickListener(v -> salvarAlerta());
        btnCancelarAlerta.setOnClickListener(v -> resetForm());

        btnNavPainel.setOnClickListener(v -> {
            Intent intent = new Intent(AlertasActivity.this, MainActivity.class);
            startActivity(intent);
            finish();
        });

        btnNavAbrigos.setOnClickListener(v -> {
            Intent intent = new Intent(AlertasActivity.this, AbrigosActivity.class);
            startActivity(intent);
            finish();
        });

        carregarAlertas();
    }

    private void salvarAlerta() {
        String titulo = edtTituloAlerta.getText().toString().trim();
        String desc = edtDescricaoAlerta.getText().toString().trim();
        String dataHora = edtDataHoraAlerta.getText().toString().trim();
        String risco = spnNivelRiscoAlerta.getSelectedItem().toString();

        if (TextUtils.isEmpty(titulo)) {
            edtTituloAlerta.setError("Informe o título do alerta");
            return;
        }

        if (TextUtils.isEmpty(dataHora)) {
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy • HH:mm", Locale.getDefault());
            dataHora = sdf.format(new Date());
        }

        if (selectedAlertaId == -1) {
            // Inserir
            Alerta novoAlerta = new Alerta(titulo, desc, dataHora, risco);
            long res = databaseHelper.insertAlerta(novoAlerta);
            if (res > 0) {
                Toast.makeText(this, "Alerta cadastrado com sucesso!", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Erro ao cadastrar alerta.", Toast.LENGTH_SHORT).show();
            }
        } else {
            // Atualizar
            Alerta alertaEdit = new Alerta(selectedAlertaId, titulo, desc, dataHora, risco);
            int res = databaseHelper.updateAlerta(alertaEdit);
            if (res > 0) {
                Toast.makeText(this, "Alerta atualizado com sucesso!", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Erro ao atualizar alerta.", Toast.LENGTH_SHORT).show();
            }
        }

        resetForm();
        carregarAlertas();
    }

    private void resetForm() {
        selectedAlertaId = -1;
        edtTituloAlerta.setText("");
        edtDescricaoAlerta.setText("");
        edtDataHoraAlerta.setText("");
        spnNivelRiscoAlerta.setSelection(0);
        txtTituloFormAlerta.setText("Cadastrar Novo Alerta");
        btnSalvarAlerta.setText("Salvar Alerta");
        btnCancelarAlerta.setVisibility(View.GONE);
    }

    private void carregarAlertas() {
        containerAlertas.removeAllViews();
        List<Alerta> list = databaseHelper.getAllAlertas();

        for (Alerta a : list) {
            View itemView = criarViewAlerta(a);
            containerAlertas.addView(itemView);
        }
    }

    private View criarViewAlerta(Alerta alerta) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(32, 32, 32, 32);

        String corFundo = "#FFEE8C"; // Médio por padrão
        if ("Alto".equalsIgnoreCase(alerta.getNivelRisco()) || alerta.getTitulo().toLowerCase().contains("alto")) {
            corFundo = "#FF9E99";
        } else if ("Baixo".equalsIgnoreCase(alerta.getNivelRisco()) || alerta.getTitulo().toLowerCase().contains("baixo")) {
            corFundo = "#9DCC9B";
        }

        card.setBackgroundColor(Color.parseColor(corFundo));

        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        params.setMargins(0, 0, 0, 24);
        card.setLayoutParams(params);

        // Linha principal de info
        LinearLayout rowInfo = new LinearLayout(this);
        rowInfo.setOrientation(LinearLayout.HORIZONTAL);
        rowInfo.setGravity(android.view.Gravity.CENTER_VERTICAL);

        ImageView imgIcon = new ImageView(this);
        LinearLayout.LayoutParams imgParams = new LinearLayout.LayoutParams(110, 110);
        imgIcon.setLayoutParams(imgParams);
        imgIcon.setImageResource(R.drawable.ic_alerta);

        LinearLayout colText = new LinearLayout(this);
        colText.setOrientation(LinearLayout.VERTICAL);
        colText.setPadding(24, 0, 0, 0);
        LinearLayout.LayoutParams colParams = new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.0f
        );
        colText.setLayoutParams(colParams);

        TextView txtTitulo = new TextView(this);
        txtTitulo.setText(alerta.getTitulo());
        txtTitulo.setTextSize(18);
        txtTitulo.setTypeface(null, android.graphics.Typeface.BOLD);
        txtTitulo.setTextColor(Color.parseColor("#59151B"));

        TextView txtDesc = new TextView(this);
        txtDesc.setText(alerta.getDescricao());
        txtDesc.setTextSize(14);
        txtDesc.setTextColor(Color.parseColor("#102B55"));
        txtDesc.setPadding(0, 4, 0, 4);

        TextView txtData = new TextView(this);
        txtData.setText(alerta.getDataHora());
        txtData.setTextSize(12);
        txtData.setTextColor(Color.parseColor("#102B55"));

        colText.addView(txtTitulo);
        colText.addView(txtDesc);
        colText.addView(txtData);

        rowInfo.addView(imgIcon);
        rowInfo.addView(colText);

        // Linha de botões de ação (Editar e Excluir)
        LinearLayout rowActions = new LinearLayout(this);
        rowActions.setOrientation(LinearLayout.HORIZONTAL);
        rowActions.setGravity(android.view.Gravity.END);
        rowActions.setPadding(0, 16, 0, 0);

        Button btnEditar = new Button(this);
        btnEditar.setText("Editar");
        btnEditar.setTextSize(12);
        btnEditar.setTextColor(Color.parseColor("#123B70"));
        btnEditar.setBackgroundColor(Color.parseColor("#E0E6ED"));
        LinearLayout.LayoutParams btnEditParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, 90
        );
        btnEditParams.setMargins(0, 0, 16, 0);
        btnEditar.setLayoutParams(btnEditParams);

        Button btnExcluir = new Button(this);
        btnExcluir.setText("Excluir");
        btnExcluir.setTextSize(12);
        btnExcluir.setTextColor(Color.WHITE);
        btnExcluir.setBackgroundColor(Color.parseColor("#D32F2F"));
        LinearLayout.LayoutParams btnDelParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, 90
        );
        btnExcluir.setLayoutParams(btnDelParams);

        btnEditar.setOnClickListener(v -> {
            selectedAlertaId = alerta.getId();
            edtTituloAlerta.setText(alerta.getTitulo());
            edtDescricaoAlerta.setText(alerta.getDescricao());
            edtDataHoraAlerta.setText(alerta.getDataHora());

            for (int i = 0; i < OPCOES_RISCO.length; i++) {
                if (OPCOES_RISCO[i].equalsIgnoreCase(alerta.getNivelRisco())) {
                    spnNivelRiscoAlerta.setSelection(i);
                    break;
                }
            }

            txtTituloFormAlerta.setText("Editar Alerta ID: " + alerta.getId());
            btnSalvarAlerta.setText("Atualizar Alerta");
            btnCancelarAlerta.setVisibility(View.VISIBLE);
        });

        btnExcluir.setOnClickListener(v -> {
            new AlertDialog.Builder(this)
                    .setTitle("Excluir Alerta")
                    .setMessage("Deseja realmente excluir " + alerta.getTitulo() + "?")
                    .setPositiveButton("Sim", (dialog, which) -> {
                        databaseHelper.deleteAlerta(alerta.getId());
                        Toast.makeText(this, "Alerta excluído!", Toast.LENGTH_SHORT).show();
                        if (selectedAlertaId == alerta.getId()) {
                            resetForm();
                        }
                        carregarAlertas();
                    })
                    .setNegativeButton("Não", null)
                    .show();
        });

        rowActions.addView(btnEditar);
        rowActions.addView(btnExcluir);

        card.addView(rowInfo);
        card.addView(rowActions);

        return card;
    }
}
